window.onmessage = (event) => {
  const message = event.data.pluginMessage;
  const resultsList = document.getElementById('resultsList');
  const iconResultsList = document.getElementById('iconResultsList');
  const debugDiv = document.getElementById('debug');

  // Display raw data in the debug tab
  debugDiv.textContent = JSON.stringify(message, null, 2);

  resultsList.innerHTML = ''; // Clear previous results
  iconResultsList.innerHTML = ''; // Clear previous icon results

  if (message.type === 'success') {
    const groupedInstances = {};
    const groupedIcons = {};

    message.instances.forEach((instance) => {
      // Если элемент является иконкой, добавляем его только в groupedIcons
      if (instance.icon === true) {
        const key = `${instance.name}-${instance.description}`;
        if (!groupedIcons[key]) {
          groupedIcons[key] = [];
        }
        groupedIcons[key].push(instance);
      } else {
        // Если элемент не является иконкой, добавляем его в groupedInstances
        const key = `${instance.name}-${instance.description}`;
        if (!groupedInstances[key]) {
          groupedInstances[key] = [];
        }
        groupedInstances[key].push(instance);
      }
    });

    // Display grouped instances (Components)
    for (const key in groupedInstances) {
      const group = groupedInstances[key];
      const firstInstance = group[0];

      const groupHeader = document.createElement('li');
      groupHeader.classList.add('group-header');

      const groupName = document.createElement('span');
      groupName.classList.add('group-name');
      groupName.textContent = `${firstInstance.name} (${group.length})`;

      groupHeader.appendChild(groupName);
      resultsList.appendChild(groupHeader);

      const groupItems = document.createElement('ul');
      groupItems.classList.add('group-items');

      group.forEach((instance) => {
        const groupItem = document.createElement('li');
        groupItem.classList.add('group-item');

        const componentContainer = document.createElement('div');
        componentContainer.classList.add('component-container');

        const componentNameContainer = document.createElement('div');
        componentNameContainer.classList.add('component-name-container');

        const nameLink = document.createElement('a');
        nameLink.href = '#';
        nameLink.classList.add('component-link');
        nameLink.textContent = instance.name || 'Без названия';

        componentNameContainer.appendChild(nameLink);

        if (instance.description) {
          const descriptionSpan = document.createElement('span');
          descriptionSpan.classList.add('description-inline');
          const fullDescription = instance.description;
          const truncatedDescription =
            fullDescription.length > 10
              ? `${fullDescription.substring(0, 10)}...`
              : fullDescription;

          descriptionSpan.textContent = truncatedDescription;
          descriptionSpan.title = fullDescription;
          componentNameContainer.appendChild(descriptionSpan);
        }

        componentContainer.appendChild(componentNameContainer);
        groupItem.appendChild(componentContainer);
        groupItems.appendChild(groupItem);
      });

      resultsList.appendChild(groupItems);
    }

    // Display grouped icons (Icons)
    for (const key in groupedIcons) {
      const group = groupedIcons[key];
      const firstInstance = group[0];

      const groupHeader = document.createElement('li');
      groupHeader.classList.add('group-header');

      const groupName = document.createElement('span');
      groupName.classList.add('group-name');
      groupName.textContent = `${firstInstance.name} (${group.length})`;

      groupHeader.appendChild(groupName);
      iconResultsList.appendChild(groupHeader);

      const groupItems = document.createElement('ul');
      groupItems.classList.add('group-items');

      group.forEach((instance) => {
        const groupItem = document.createElement('li');
        groupItem.classList.add('group-item');

        const componentContainer = document.createElement('div');
        componentContainer.classList.add('component-container');

        const componentNameContainer = document.createElement('div');
        componentNameContainer.classList.add('component-name-container');

        const nameLink = document.createElement('a');
        nameLink.href = '#';
        nameLink.classList.add('component-link');
        nameLink.textContent = instance.name || 'Без названия';

        componentNameContainer.appendChild(nameLink);

        if (instance.description) {
          const descriptionSpan = document.createElement('span');
          descriptionSpan.classList.add('description-inline');
          const fullDescription = instance.description;
          const truncatedDescription =
            fullDescription.length > 10
              ? `${fullDescription.substring(0, 10)}...`
              : fullDescription;

          descriptionSpan.textContent = truncatedDescription;
          descriptionSpan.title = fullDescription;
          componentNameContainer.appendChild(descriptionSpan);
        }

        componentContainer.appendChild(componentNameContainer);
        groupItem.appendChild(componentContainer);
        groupItems.appendChild(groupItem);
      });

      iconResultsList.appendChild(groupItems);
    }
  }
};
