// Show the UI
figma.showUI(__html__, { width: 600, height: 1000 });

// Add cache storage at the top level
const componentUpdateCache = new Map();

/**
 * Получает уникальный ключ кэширования для компонента
 * Если компонент находится в наборе компонентов (COMPONENT_SET),
 * использует комбинацию ключа родителя и имени компонента,
 * иначе использует собственный ключ компонента
 * @param {ComponentNode} component - Компонент для получения ключа
 * @returns {string} Уникальный ключ для кэширования
 */
function getComponentCacheKey(component) {
  if (component.parent.type === 'COMPONENT_SET') {
    return `${component.parent.key}_${component.name}`;
  }
  return component.key;
}

/**
 * Проверяет, требует ли компонент обновления
 * Сравнивает текущий компонент с импортированной версией
 * Использует кэширование для оптимизации повторных проверок
 * @param {ComponentNode} mainComponent - Компонент для проверки
 * @returns {Promise<{isOutdated: boolean, importedId: string|null}>}
 */
async function checkComponentUpdate(mainComponent) {
  const cacheKey = getComponentCacheKey(mainComponent);
  
  // Check if we already have the result in cache
  if (componentUpdateCache.has(cacheKey)) {
    console.log('Using cached result for:', mainComponent.name);
    return componentUpdateCache.get(cacheKey);
  }

  let result = {
    isOutdated: false,
    importedId: null
  };

  try {
    const isPartOfSet = mainComponent.parent.type === 'COMPONENT_SET';
    let importedComponent = null;
    let importedSet = null;

    if (isPartOfSet && mainComponent.parent.key) {
      const importedSet = await figma.importComponentSetByKeyAsync(mainComponent.parent.key);
      importedComponent = importedSet.findOne(comp => 
        comp.name === mainComponent.name && 
        comp.type === 'COMPONENT' 
      );
    } else {
      importedComponent = await figma.importComponentAsync(mainComponent.key);
    }

    result = {
      isOutdated: importedComponent ? importedComponent.id !== mainComponent.id : false,
      importedId: importedComponent.id || null
    };

    // Cache the result
    componentUpdateCache.set(cacheKey, result);
    
    console.log('Component check:', {
      name: mainComponent.name,
      cacheKey,
      originalId: mainComponent.id,
      importedId: result.importedId,
      isOutdated: result.isOutdated
    });

  } catch (error) {
    console.error('Error checking component updates:', {
      componentName: mainComponent.name,
      error: error.message
    });
  }

  return result;
}

/**
 * Получает полный путь к узлу через всех его родителей
 * Формирует строку из ID всех родительских узлов, разделенных запятыми
 * @param {SceneNode} node - Узел для получения пути
 * @returns {string} Строка пути, состоящая из ID узлов
 */
function getNodePath(node) {
  const path = [];
  let current = node;

  // Collect all IDs along the parent chain
  while (current && current.parent) {
    path.unshift(current.id);
    current = current.parent;
  }

  // Form the path string, adding the necessary separators
  return path.join(',');
}

/**
 * Извлекает версию из описания, если она соответствует паттерну
 * @param {string} description - Описание компонента
 * @returns {string|null} Версия или null, если паттерн не найден
 */
function extractVersion(description) {
  if (!description) return null;
  
  // Паттерн: "v" + пробел + три числа, разделенные точками
  const versionPattern = /^v\s+(\d+\.\d+\.\d+)/;
  const match = description.match(versionPattern);
  
  return match ? match[1] : null;
}

/**
 * Получает описание узла
 * Проверяет наличие описания в следующем порядке:
 * 1. У самого узла
 * 2. У главного компонента
 * 3. У родителя главного компонента
 * @param {SceneNode} node - Узел для получения описания
 * @returns {Object} Объект с описанием и версией
 */
function getDescription(node) {
  let description = node.description;
  let nodeVersion = null;

  if (!description && node.mainComponent) {
    description = node.mainComponent.description;
    if (!description && node.mainComponent.parent) {
      description = node.mainComponent.parent.description;
    }
  }

  if (description) {
    nodeVersion = extractVersion(description);
  }

  return {
    description: description || "",
    nodeVersion: nodeVersion
  };
}

/**
 * Проверяет, скрыт ли узел или любой из его родителей
 * Рекурсивно проверяет свойство visible для узла и всех его родителей
 * @param {SceneNode} node - Узел для проверки
 * @returns {boolean} true если узел или любой из родителей скрыт
 */
function isNodeOrParentHidden(node) {
  let currentNode = node;
  while (currentNode) {
    if (currentNode.visible === false) {
      return true; // Если текущий узел скрыт, возвращаем true
    }
    currentNode = currentNode.parent; // Переходим к родителю
  }
  return false; // Если ни один из узлов не скрыт, возвращаем false
}

/**
 * Проверяет, является ли узел вложенным в другой экземпляр
 * Рекурсивно проверяет родителей узла на тип INSTANCE
 * @param {SceneNode} node - Узел для проверки
 * @returns {boolean} true если узел вложен в другой экземпляр
 */
function isNestedInstance(node) {
  let parent = node.parent;
  while (parent) {
    if (parent.type === 'INSTANCE') {
      return true;
    }
    parent = parent.parent;
  }
  return false;
}

// Добавляем вспомогательную функцию для задержки
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Добавляем функцию для отправки прогресса
async function updateProgress(phase, processed, total, message) {
  figma.ui.postMessage({
    type: 'progress-update',
    phase,
    processed,
    total,
    message
  });
  // Небольшая задержка для обработки UI
  await delay(10);
}

/**
 * Основной обработчик сообщений от UI плагина
 * Обрабатывает следующие типы сообщений:
 * 
 * 1. 'list-instances':
 *    - Ищет все экземпляры компонентов в выбранном фрейме/секции
 *    - Собирает информацию о каждом экземпляре (имя, размеры, описание и т.д.)
 *    - Определяет, является ли компонент иконкой на основе размеров и имени
 *    - Отправляет собранные данные обратно в UI
 * 
 * 2. 'list-colors':
 *    - Анализирует все элементы в выбранном фрейме/секции на наличие цветов
 *    - Собирает информацию о заливках, обводках и связанных переменных
 *    - Проверяет API переменных Figma и логирует отладочную информацию
 *    - Отправляет собранные данные о цветах обратно в UI
 * 
 * 3. 'scroll-to-node':
 *    - Находит узел по переданному ID
 *    - Прокручивает и масштабирует вид к найденному узлу
 *    - Выделяет узел в интерфейсе Figma
 * 
 * 4. 'select-nodes':
 *    - Принимает массив ID узлов
 *    - Находит все указанные узлы
 *    - Выделяет группу узлов в интерфейсе Figma
 *    - Прокручивает вид к выделенным узлам
 * 
 * 5. 'check-all':
 *    - Последовательно вызывает проверку компонентов и цветов
 *    - Собирает и отправляет результаты проверки в UI
 * 
 * @param {Object} msg - Объект сообщения от UI
 * @param {string} msg.type - Тип сообщения ('list-instances', 'list-colors', 'scroll-to-node', 'select-nodes', 'check-all')
 * @param {string} [msg.nodeId] - ID узла для прокрутки (для 'scroll-to-node')
 * @param {string[]} [msg.nodeIds] - Массив ID узлов для выделения (для 'select-nodes')
 */
figma.ui.onmessage = async (msg) => {
  // Обработка запроса на комплексную проверку
  if (msg.type === 'check-all') {
    const selection = figma.currentPage.selection;

    // Проверяем, выбран ли хотя бы один элемент
    if (!selection || selection.length === 0) {
      figma.ui.postMessage({ 
        type: 'error', 
        message: 'Выберите фрейм, компонент или инстанс!' 
      });
      return;
    }

    const container = selection[0];
    let componentsResult = {
      instances: [],
      counts: {
        components: 0,
        icons: 0
      }
    };
    let colorsResult = {
      instances: [],
      counts: {
        colors: 0
      }
    };

    try {
      let nodesToProcess = [];

      // Определяем, какие узлы нужно обработать
      if (container.type === 'INSTANCE') {
        // Если выбран инстанс, обрабатываем его и все его внутренние элементы
        nodesToProcess = [container, ...container.findAll()];
      } else if (container.type === 'COMPONENT') {
        // Если выбран компонент, обрабатываем только его
        nodesToProcess = [container];
      } else if (typeof container.findAll === 'function') {
        // Если выбран фрейм или другой контейнер, получаем все его дочерние элементы
        nodesToProcess = container.findAll();
      } else {
        figma.ui.postMessage({ 
          type: 'error', 
          message: 'Выбранный элемент не поддерживается. Пожалуйста, выберите фрейм, компонент или инстанс.' 
        });
        return;
      }
      
      // Инициализация прогресса
      await updateProgress('processing', 0, nodesToProcess.length, 'Обработка элементов');

      // Проходим по каждому узлу
      for (let i = 0; i < nodesToProcess.length; i++) {
        const node = nodesToProcess[i];
        
        // Проверяем цвета для каждого элемента
        if (hasFillOrStroke(node)) {
          const colorData = await processNodeColors(node);
          if (colorData) {
            colorsResult.instances.push(colorData);
            colorsResult.counts.colors++;
          }
        }

        // Дополнительно проверяем компоненты для элементов типа INSTANCE
        if (node.type === 'INSTANCE' && node.mainComponent) {
          const instanceData = await processNodeComponent(node);
          if (instanceData) {
            componentsResult.instances.push(instanceData);
            if (instanceData.icon) {
              componentsResult.counts.icons++;
            } else {
              componentsResult.counts.components++;
            }
          }
        }

        // Обновляем прогресс каждые 5 элементов или на последнем элементе
        if (i % 5 === 0 || i === nodesToProcess.length - 1) {
          await updateProgress('processing', i + 1, nodesToProcess.length, 'Обработка элементов');
        }
      }

      // Сортируем результаты
      componentsResult.instances.sort((a, b) => a.name.localeCompare(b.name));
      
    } catch (error) {
      // console.error('Ошибка при проверке:', error);
      figma.notify(`Ошибка при проверке: ${error.message}`);
      figma.ui.postMessage({ 
        type: 'error', 
        message: `Ошибка при проверке: ${error.message}` 
      });
      return;
    }

    // Отправляем финальный результат
    figma.ui.postMessage({
      type: 'all-results',
      components: componentsResult,
      colors: colorsResult
    });
  } 
  // Обработка запроса на получение списка экземпляров компонентов
  
  // Обработка запроса на получение списка цветов
  else if (msg.type === 'list-colors') {
    // console.log("\n\n========= НАЧАЛО ОБРАБОТКИ СООБЩЕНИЯ list-colors =========");
    // console.log("Время начала:", new Date().toISOString());
    
    // Тестирование API переменных Figma
    // Проверяем доступность и работоспособность API
    // console.log("ТЕСТ: Проверяем API переменных Figma");
    // console.log("Доступные методы figma.variables:", Object.keys(figma.variables));
    
    try {
      // Получаем и проверяем локальные переменные
      // console.log("ТЕСТ: Получаем все локальные переменные");
      const localVars = await figma.variables.getLocalVariablesAsync();
      // console.log(`ТЕСТ: Получено ${localVars.length} локальных переменных`);
      
      // Тестируем работу с первой найденной переменной
      if (localVars.length > 0) {
        // console.log("ТЕСТ: Первая локальная переменная:", {
        //   id: localVars[0].id,
        //   name: localVars[0].name,
        //   key: localVars[0].key
        // });
        
        // console.log(`ТЕСТ: Пробуем получить переменную по ID: ${localVars[0].id}`);
        const testVar = await figma.variables.getVariableByIdAsync(localVars[0].id);
        // console.log("ТЕСТ: Результат вызова getVariableByIdAsync:", testVar ? {
        //   id: testVar.id,
        //   name: testVar.name,
        //   key: testVar.key
        // } : "не найдена");
      }
    } catch (testError) {
      // console.error("ТЕСТ: Ошибка при тестировании API переменных:", testError);
    }
    
    // Проверяем наличие выбранных элементов
    const selection = figma.currentPage.selection;

    if (!selection || selection.length === 0) {
      // console.log("Ошибка: Нет выбранных элементов");
      figma.ui.postMessage({ type: 'error', message: 'Выберите фрейм или секцию!' });
      return;
    }

    // Собираем информацию о цветах
    try {
      // console.log('Начинаем сбор информации о цветах...');
    const container = selection[0];
      // console.log(`Выбран контейнер: ${container.name}, type: ${container.type}, id: ${container.id}`);
      
      // Вызываем функцию сбора цветов и обрабатываем результаты
      // console.log('Вызываем функцию collectColors');
      const colorData = await collectColors(container);
      // console.log(`Собрано ${colorData.length} элементов с цветами`);
      
      // Отправляем результаты в UI
      if (colorData.length === 0) {
        // console.log("Ошибка: Цвета не найдены");
        figma.ui.postMessage({ type: 'error', message: 'Цвета не найдены!' });
      } else {
        // Логируем примеры собранных данных для отладки
        // console.log('Пример собранных данных (первые 3 элемента):', 
        //   colorData.slice(0, 3).map(item => ({
        //     name: item.name,
        //     fill: item.fill,
        //     fill_variable_name: item.fill_variable_name,
        //     stroke: item.stroke,
        //     stroke_variable_name: item.stroke_variable_name
        //   }))
        // );
        
        // Отправляем данные в UI
        // console.log('Отправляем данные в UI');
        figma.ui.postMessage({ 
          type: 'success', 
          instances: colorData,
          counts: {
            components: 0,
            icons: 0,
            colors: colorData.length
          }
        });
      }
    } catch (error) {
      // console.error('Ошибка при сборе цветов:', error);
      figma.notify(`Ошибка при сборе цветов: ${error.message}`);
      figma.ui.postMessage({ type: 'error', message: `Ошибка при сборе цветов: ${error.message}` });
    }
    
    // console.log("Время окончания:", new Date().toISOString());
    // console.log("========= КОНЕЦ ОБРАБОТКИ СООБЩЕНИЯ list-colors =========\n\n");
  } 
  // Обработка запроса на прокрутку к определенному узлу
  else if (msg.type === 'scroll-to-node') {
    const nodeId = msg.nodeId;

    // Ищем узел по ID
    // console.log('Ищем узел с ID:', nodeId);
    const node = figma.getNodeById(nodeId);

    // Если узел найден, прокручиваем к нему и выделяем
    if (node) {
      // Прокручиваем и увеличиваем масштаб до выбранного узла
      figma.viewport.scrollAndZoomIntoView([node]);
      figma.currentPage.selection = [node]; // Выделяем узел
    } else {
      // console.error('Узел не найден:', nodeId);
      figma.notify('Не удалось найти узел с указанным ID.');
    }
  } 
  // Обработка запроса на выбор группы узлов
  else if (msg.type === 'select-nodes') {
    const nodeIds = msg.nodeIds;
    // console.log('Выбираем группу узлов:', nodeIds);
    
    // Проверяем корректность входных данных
    if (!nodeIds || nodeIds.length === 0) {
      figma.notify('Не указаны ID узлов для выбора');
      return;
    }
    
    // Находим все узлы по их ID и фильтруем несуществующие
    const nodes = nodeIds
      .map(id => figma.getNodeById(id))
      .filter(node => node !== null);
    
    // Проверяем, найдены ли узлы
    if (nodes.length === 0) {
      figma.notify('Не удалось найти ни один из указанных узлов');
      return;
    }
    
    // Выделяем найденные узлы и прокручиваем к ним
    figma.currentPage.selection = nodes;
    
    if (nodes.length > 0) {
      figma.viewport.scrollAndZoomIntoView(nodes);
      figma.notify(`Выбрано ${nodes.length} элементов`);
    }
  }
};

/**
 * Собирает информацию о цветах во всех узлах контейнера
 * Анализирует заливки и обводки, собирает информацию о:
 * - Цветах (hex)
 * - Переменных цвета
 * - Коллекциях цветов
 * - Родительских компонентах
 * @param {ContainerNode} container - Контейнер для анализа
 * @returns {Promise<Array>} Массив данных о цветах
 */
async function collectColors(container) {
  const colorData = [];
  const allNodes = container.findAll();
  
  // console.log(`Анализируем ${allNodes.length} узлов`);
  // console.log('---------------- НАЧАЛО СБОРА ЦВЕТОВ ----------------');
  
  // Проходим по всем узлам
    for (const node of allNodes) {
    // Проверяем наличие свойств fill и stroke
    if (hasFillOrStroke(node)) {
      const nodeData = {
        name: node.name,
        nodeId: node.id,
        key: node.key,
        modifiedName: node.name, // Для совместимости с существующим UI
        color: true, // Метка для отображения во вкладке цветов
        description: getDescription(node),
        hidden: isNodeOrParentHidden(node) // Добавляем информацию о скрытости элемента
      };
      
      // Находим родителя с типом INSTANCE, если он есть
      let parentComponentName = null;
      let parentNode = node.parent;

      // Используем существующую логику поиска родительского компонента
      while (parentNode && !parentComponentName) {
        if (parentNode.type === 'INSTANCE' && parentNode.mainComponent) {
          parentComponentName = parentNode.mainComponent.name;
          if (parentNode.mainComponent.parent && parentNode.mainComponent.parent.type === 'COMPONENT_SET') {
            parentComponentName = parentNode.mainComponent.parent.name;
          }
        }
        parentNode = parentNode.parent;
      }

      // Если нашли родительский компонент, добавляем информацию о нем
      if (parentComponentName) {
        nodeData.parentComponentName = parentComponentName;
      }
      
      // Предотвращаем ошибку с преобразованием Symbol в строку
      const safeName = node.name === figma.mixed ? "Смешанное значение" : node.name;
      
      // Логируем узел для отладки
      // console.log(`\n====== Найден узел с цветом: ${safeName}, type: ${node.type} ======`);
      
      // Проверяем, есть ли у узла boundVariables
      if (node.boundVariables) {
        try {
          // console.log(`Узел имеет boundVariables:`, safeStringify(node.boundVariables));
          
          // Проверяем fills и strokes напрямую
          // console.log('Проверка boundVariables.fills:', 
          //   node.boundVariables.fills ? safeStringify(node.boundVariables.fills) : 'undefined');
          // console.log('Проверка boundVariables.strokes:', 
          //   node.boundVariables.strokes ? safeStringify(node.boundVariables.strokes) : 'undefined');
        } catch (error) {
          // console.log('Ошибка при логировании boundVariables:', error.message);
        }
      } else {
        // console.log('Узел НЕ имеет boundVariables');
      }
      
      // Обрабатываем заливку (fill)
      if (node.fills && node.fills.length > 0) {
        for (const fill of node.fills) {
          if (fill.type === 'SOLID' && fill.visible !== false) {
            // Проверяем, что цвет не figma.mixed
            if (fill.color && fill.color.r !== figma.mixed && fill.color.g !== figma.mixed && fill.color.b !== figma.mixed) {
              // Получаем цвет в hex формате
              const fillColor = rgbToHex(fill.color.r, fill.color.g, fill.color.b);
              nodeData.fill = fillColor;
              
              // Логируем информацию о заливке
              // console.log(`Fill: ${fillColor}, opacity: ${nodeData.fill_opacity}`);
            } else {
              // console.log('Пропускаем заливку со смешанным значением цвета');
              nodeData.fill = '#MIXED';
              nodeData.fill_opacity = 1;
            }
            
            break; // Берем только первую видимую заливку
          }
        }
      }
      
      // Обрабатываем обводку (stroke)
      if (node.strokes && node.strokes.length > 0) {
        for (const stroke of node.strokes) {
          if (stroke.type === 'SOLID' && stroke.visible !== false) {
            // Проверяем, что цвет не figma.mixed
            if (stroke.color && stroke.color.r !== figma.mixed && stroke.color.g !== figma.mixed && stroke.color.b !== figma.mixed) {
              // Получаем цвет в hex формате
              const strokeColor = rgbToHex(stroke.color.r, stroke.color.g, stroke.color.b);
              nodeData.stroke = strokeColor;
              
              // Логируем информацию об обводке
              // console.log(`Stroke: ${strokeColor}, opacity: ${nodeData.stroke_opacity}, weight: ${nodeData.stroke_weight}`);
            } else {
              // console.log('Пропускаем обводку со смешанным значением цвета');
              nodeData.stroke = '#MIXED';
              //nodeData.stroke_opacity = 1;
              //nodeData.stroke_weight = 1;
            }
            
            break; // Берем только первую видимую обводку
          }
        }
      }
      
      // Получаем информацию о переменных для всех возможных типов привязок
      try {
        // console.log('Начинаем обработку переменных для узла:', safeName);
        
        // Проверяем boundVariables и обрабатываем различные структуры
        if (node.boundVariables) {
          // Для заливки
          // console.log('Вызываем processVariableBindings для fills');
          await processVariableBindings(node, nodeData, 'fills', 'fill');
          
          // Для обводки
          // console.log('Вызываем processVariableBindings для strokes');
          await processVariableBindings(node, nodeData, 'strokes', 'stroke');
        } else {
          // console.log('У узла нет boundVariables, пропускаем обработку переменных');
        }
        
        // console.log('Обработка переменных завершена для узла:', safeName);
      } catch (error) {
        // console.error('Ошибка при обработке переменных:', error);
      }
      
      // Проверяем условие: игнорируем элементы с цветом #000000 и родителем "source"
      const hasBlackColor = (nodeData.fill === '#000000' || nodeData.stroke === '#000000');
      let hasSourceParent = false;
      
      // Проверяем, есть ли у элемента родитель с именем "source"
      let parent = node.parent;
      while (parent) {
        if (parent.name && parent.name.toLowerCase().includes('source')) {
          hasSourceParent = true;
          break;
        }
        parent = parent.parent;
      }
      
      // Логируем информацию о фильтрации
      if (hasBlackColor && hasSourceParent) {
        // console.log(`Игнорируем элемент ${safeName} с черным цветом и родителем source`);
      } else {
        // Добавляем узел в набор данных, только если он не соответствует критериям фильтрации
        colorData.push(nodeData);
      }
    }
  }
  
  // console.log('---------------- КОНЕЦ СБОРА ЦВЕТОВ ----------------');
  // console.log(`Всего собрано ${colorData.length} элементов с цветами`);
  return colorData;
}

/**
 * Обрабатывает привязки переменных для узла
 * Получает информацию о переменных цвета для заливок и обводок
 * Собирает данные о:
 * - Имени переменной
 * - ID переменной
 * - Коллекции переменной
 * @param {SceneNode} node - Узел для обработки
 * @param {Object} nodeData - Объект для сохранения данных
 * @param {string} propertyType - Тип свойства (fills/strokes)
 * @param {string} prefix - Префикс для сохранения данных
 */
async function processVariableBindings(node, nodeData, propertyType, prefix) {
  // Защита от ошибки с преобразованием Symbol в строку
  const safeName = node.name === figma.mixed ? "Смешанное значение" : node.name;
  
  // Ранние отладочные сообщения
  // console.log(`\n>>>> НАЧАЛО processVariableBindings для ${propertyType} <<<<`);
  // console.log(`Проверяемый узел: ${safeName}, тип: ${node.type}`);
  // console.log(`Проверяем наличие boundVariables[${propertyType}]`);
  
  // Проверка на null или undefined
  if (!node.boundVariables) {
    // console.log(`ОШИБКА: node.boundVariables равен ${node.boundVariables}`);
    return;
  }
  
  // Проверяем наличие свойства в boundVariables
  if (node.boundVariables[propertyType]) {
    // console.log(`Найдены привязки для ${propertyType}:`, safeStringify(node.boundVariables[propertyType]));
    
    // Получаем все возможные ID переменных для этого свойства
    let variableId = null;
    
    // Массив с привязками
    if (Array.isArray(node.boundVariables[propertyType])) {
      // console.log(`boundVariables[${propertyType}] - это массив длиной ${node.boundVariables[propertyType].length}`);
      
      // Проверяем первый элемент массива
      const binding = node.boundVariables[propertyType][0];
      // console.log(`Привязка-- ${propertyType}[0]:`, binding ? safeStringify(binding) : 'undefined');
      
      // Проверяем все возможные структуры для получения ID переменной
      if (binding) {
        // console.log(`Структура binding: ${Object.keys(binding).join(', ')}`);
        
        // Проверяем прямую структуру, где id на самом объекте binding
        if (binding.id && binding.type === 'VARIABLE_ALIAS') {
          // console.log(`Найден прямой id в binding:`, binding.id);
          variableId = binding.id;
          // console.log(` NEW——— ${variableId} ———`);
        }
        // Старая проверка для совместимости
        else if (binding.color) {
          // console.log(`binding.color найден:`, binding.color);
          variableId = binding.color.id;
          // console.log(` 2——— ${variableId} ———`);
          // console.log(`ID переменной для ${propertyType}[0].color:`, variableId);
        } else {
          // console.log(`binding.color не найден в структуре`);
        }
      }
    } 
    // Объект с привязками
    else if (typeof node.boundVariables[propertyType] === 'object') {
      // console.log(`boundVariables[${propertyType}] - это объект`);
      // console.log(`Структура объекта: ${Object.keys(node.boundVariables[propertyType]).join(', ')}`);
      
      // Проверка для прямой структуры, где id на самом объекте
      if (node.boundVariables[propertyType].id && node.boundVariables[propertyType].type === 'VARIABLE_ALIAS') {
        // console.log(`Найден прямой id в объекте:`, node.boundVariables[propertyType].id);
        variableId = node.boundVariables[propertyType].id;
        // console.log(` NEW2——— ${variableId} ———`);
      }
      // Старая проверка для совместимости
      else if (node.boundVariables[propertyType].color) {
        // console.log(`Найден ${propertyType}.color:`, node.boundVariables[propertyType].color);
        variableId = node.boundVariables[propertyType].color.id;
        // console.log(` 1——— ${variableId} ———`);
        
        // console.log(`ID переменной для ${propertyType}.color:`, variableId);
      } else {
        // console.log(`Свойство color не найдено в объекте`);
      }
    } else {
      // console.log(`boundVariables[${propertyType}] имеет неожиданный тип: ${typeof node.boundVariables[propertyType]}`);
    }
    

    // Если нашли ID переменной, получаем информацию о ней
    if (variableId) {
      // console.log(`\nID переменной найден: ${variableId}`);
      try {
        // console.log(`Получаем переменную по ID: ${variableId}`);
        
        // Детальный лог доступных методов API
        // console.log("Доступные методы figma.variables:", Object.keys(figma.variables));
        
        // Попробуем получить переменную разными способами
        let variable = null;
        
        // Метод 1: Через getVariableByIdAsync
        try {
          // console.log("Метод 1: Вызываем getVariableByIdAsync");
          variable = await figma.variables.getVariableByIdAsync(variableId);
          // console.log("Результат getVariableByIdAsync:", variable);
        } catch (error) {
          // console.error("Ошибка в методе 1:", error);
        }
        
        // Метод 2: Через getLocalVariablesAsync с фильтрацией по ID
        if (!variable) {
          try {
            // console.log("Метод 2: Получаем все локальные переменные и ищем по ID");
            const allVariables = await figma.variables.getLocalVariablesAsync();
            // console.log(`Получено ${allVariables.length} локальных переменных`);
            
            variable = allVariables.find(v => v.id === variableId);
            // console.log("Найдена переменная через lokallVariables:", variable);
          } catch (error) {
            // console.error("Ошибка в методе 2:", error);
          }
        }
        
        if (variable) {
          // console.log(`Переменная найдена:`, variable);
          // console.log(`Имя переменной: ${variable.name}`);
          // console.log(`ID переменной: ${variable.id}`);
          // console.log(`Ключ переменной: ${variable.key}`);
          // console.log(`ID коллекции: ${variable.variableCollectionId}`);
          
          // Получаем коллекцию переменной
          try {
            // console.log(`Получаем коллекцию по ID: ${variable.variableCollectionId}`);
            const collection = await figma.variables.getVariableCollectionByIdAsync(variable.variableCollectionId);
            // console.log(`Результат getVariableCollectionByIdAsync:`, collection);
            
            if (collection) {
              // console.log(`Имя коллекции: ${collection.name}`);
              // console.log(`ID коллекции: ${collection.id}`);
            }
          } catch (error) {
            // console.error(`Ошибка при получении коллекции:`, error);
          }
          
          // Сохраняем данные о переменной
          nodeData[`${prefix}_variable_name`] = variable.name || 'Неизвестная переменная';
          nodeData[`${prefix}_variable_id`] = variable.id;
          nodeData[`${prefix}_variable_key`] = variable.key;
          
          try {
            const collection = await figma.variables.getVariableCollectionByIdAsync(variable.variableCollectionId);
            if (collection) {
              nodeData[`${prefix}_collection_name`] = collection.name || 'Неизвестная коллекция';
              nodeData[`${prefix}_collection_id`] = collection.id;
            }
          } catch (error) {
            // console.error(`Ошибка при получении и сохранении коллекции:`, error);
            nodeData[`${prefix}_collection_name`] = 'Ошибка получения коллекции';
          }
        } else {
          // console.log(`Переменная не найдена по ID: ${variableId}`);
          nodeData[`${prefix}_variable_name`] = 'Переменная не найдена';
          nodeData[`${prefix}_variable_id`] = variableId;
        }
      } catch (error) {
        // console.error(`Ошибка при получении переменной для ${propertyType}:`, error);
        nodeData[`${prefix}_variable_name`] = `Ошибка: ${error.message}`;
        nodeData[`${prefix}_variable_id`] = variableId;
      }
    }
  }
}

/**
 * Проверяет наличие заливки или обводки у узла
 * Анализирует свойства fills и strokes на наличие видимых
 * сплошных цветов (SOLID)
 * @param {SceneNode} node - Узел для проверки
 * @returns {boolean} true если узел имеет заливку или обводку
 */
function hasFillOrStroke(node) {
  try {
    // Проверяем node.fills
    if (node.fills && node.fills.length > 0 && node.fills.some(fill => {
      return fill.type === 'SOLID' && fill.visible !== false && 
             fill.color && typeof fill.color === 'object' &&
             fill.color.r !== figma.mixed && fill.color.g !== figma.mixed && fill.color.b !== figma.mixed;
    })) {
      return true;
    }
    
    // Проверяем node.strokes
    if (node.strokes && node.strokes.length > 0 && node.strokes.some(stroke => {
      return stroke.type === 'SOLID' && stroke.visible !== false &&
             stroke.color && typeof stroke.color === 'object' &&
             stroke.color.r !== figma.mixed && stroke.color.g !== figma.mixed && stroke.color.b !== figma.mixed;
    })) {
      return true;
    }
    
    return false;
  } catch (error) {
    // console.error('Ошибка при проверке заливки/обводки:', error.message);
    return false;
  }
}

/**
 * Преобразует RGB цвет в HEX формат
 * Обрабатывает особые случаи:
 * - figma.mixed значения
 * - Некорректные значения
 * - Масштабирование из диапазона 0-1 в 0-255
 * @param {number} r - Красный компонент (0-1)
 * @param {number} g - Зеленый компонент (0-1)
 * @param {number} b - Синий компонент (0-1)
 * @returns {string} Цвет в формате HEX (#RRGGBB)
 */
function rgbToHex(r, g, b) {
  // Проверка на Symbol (figma.mixed)
  if (r === figma.mixed || g === figma.mixed || b === figma.mixed) {
    // console.log('Обнаружено figma.mixed в цветовых компонентах');
    return '#MIXED';
  }
  
  // Убедимся, что значения определены и являются числами
  if (typeof r !== 'number' || typeof g !== 'number' || typeof b !== 'number') {
    // console.error(`Некорректные значения для RGB: r=${r}, g=${g}, b=${b}`);
    return '#ERROR';
  }
  
  // Масштабируем значения от 0-1 до 0-255
  r = Math.round(r * 255);
  g = Math.round(g * 255);
  b = Math.round(b * 255);
  
  // Проверяем границы значений
  r = Math.max(0, Math.min(255, r));
  g = Math.max(0, Math.min(255, g));
  b = Math.max(0, Math.min(255, b));
  
  // Преобразуем в шестнадцатеричный формат
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
}

/**
 * Безопасно сериализует объект в JSON строку
 * Обрабатывает специальные случаи:
 * - Symbol значения
 * - Циклические ссылки
 * - Несериализуемые объекты
 * @param {Object} obj - Объект для сериализации
 * @returns {string} JSON строка или сообщение об ошибке
 */
function safeStringify(obj) {
  try {
    return JSON.stringify(obj, (key, value) => {
      // Заменяем Symbol на строковое представление
      if (typeof value === 'symbol') {
        return 'Symbol(' + value.description + ')';
      }
      return value;
    });
  } catch (error) {
    // console.error('Ошибка при сериализации объекта:', error.message);
    return '"[Объект не может быть сериализован]"';
  }
}

/**
 * Обрабатывает цвета для отдельного узла
 * @param {SceneNode} node - Узел для обработки
 * @returns {Promise<Object|null>} Данные о цветах узла или null
 */
async function processNodeColors(node) {
  const nodeData = {
    name: node.name,
    nodeId: node.id,
    key: node.key,
    modifiedName: node.name,
    color: true,
    description: getDescription(node),
    hidden: isNodeOrParentHidden(node),
    type: node.type
  };

  // Находим родительский компонент
  let parentComponentName = null;
  let parentNode = node.parent;
  
  while (parentNode && !parentComponentName) {
    if (parentNode.type === 'INSTANCE' && parentNode.mainComponent) {
      parentComponentName = parentNode.mainComponent.name;
      if (parentNode.mainComponent.parent && parentNode.mainComponent.parent.type === 'COMPONENT_SET') {
        parentComponentName = parentNode.mainComponent.parent.name;
      }
    }
    parentNode = parentNode.parent;
  }

  if (parentComponentName) {
    nodeData.parentComponentName = parentComponentName;
  }

  // Обрабатываем заливку
  if (node.fills && node.fills.length > 0) {
    for (const fill of node.fills) {
      if (fill.type === 'SOLID' && fill.visible !== false) {
        if (fill.color && fill.color.r !== figma.mixed && fill.color.g !== figma.mixed && fill.color.b !== figma.mixed) {
          nodeData.fill = rgbToHex(fill.color.r, fill.color.g, fill.color.b);
        } else {
          nodeData.fill = '#MIXED';
        }
        break;
      }
    }
  }

  // Обрабатываем обводку
  if (node.strokes && node.strokes.length > 0) {
    for (const stroke of node.strokes) {
      if (stroke.type === 'SOLID' && stroke.visible !== false) {
        if (stroke.color && stroke.color.r !== figma.mixed && stroke.color.g !== figma.mixed && stroke.color.b !== figma.mixed) {
          nodeData.stroke = rgbToHex(stroke.color.r, stroke.color.g, stroke.color.b);
    } else {
          nodeData.stroke = '#MIXED';
        }
        break;
      }
    }
  }

  // Обрабатываем переменные
  if (node.boundVariables) {
    await processVariableBindings(node, nodeData, 'fills', 'fill');
    await processVariableBindings(node, nodeData, 'strokes', 'stroke');
  }

  // Проверяем условия фильтрации
  const hasBlackColor = (nodeData.fill === '#000000' || nodeData.stroke === '#000000');
  let hasSourceParent = false;
  
  let parent = node.parent;
  while (parent) {
    if (parent.name && parent.name.toLowerCase().includes('source')) {
      hasSourceParent = true;
      break;
    }
    parent = parent.parent;
  }

  // Возвращаем null если элемент нужно отфильтровать
  if (hasBlackColor && hasSourceParent) {
    return null;
  }

  return nodeData;
}

/**
 * Обрабатывает компонент для отдельного узла
 * @param {InstanceNode} node - Узел компонента для обработки
 * @returns {Promise<Object|null>} Данные о компоненте или null
 */
async function processNodeComponent(node) {
  const mainComponent = node.mainComponent;
  let name = mainComponent.name;
  let parentComponentName = null;
  let parentNode = node.parent;

  const isNested = isNestedInstance(node);
  const descriptionData = getDescription(node);

  while (parentNode && !parentComponentName) {
    if (parentNode.type === 'INSTANCE' && parentNode.mainComponent) {
      parentComponentName = parentNode.mainComponent.name;
      if (parentNode.mainComponent.parent && parentNode.mainComponent.parent.type === 'COMPONENT_SET') {
        parentComponentName = parentNode.mainComponent.parent.name;
      }
    }
    parentNode = parentNode.parent;
  }

  if (mainComponent.parent && mainComponent.parent.type === 'COMPONENT_SET') {
    name = mainComponent.parent.name;
  }

  if (typeof name === 'string' && name.trim() !== "") {
    const width = Math.round(node.width);
    const height = Math.round(node.height);

    const dimensionsMatch = width === height;
    const nameStartsWithNumber = /^\d+/.test(name);
    const hasSlashAfterNumber = /^\d+\s\//.test(name);
    const hasNumberTextSlashPattern = /^\d+\s.+\s\/\s/.test(name);
    
    const isIcon = dimensionsMatch && 
                    (nameStartsWithNumber && hasSlashAfterNumber || hasNumberTextSlashPattern);

    return {
      type: node.type,
      name: name.trim(),
      modifiedName: name.trim().replace(' (new)', ''),
      description: descriptionData.description,
      nodeVersion: descriptionData.nodeVersion,
      hidden: isNodeOrParentHidden(node),
      nodeId: node.id,
      isLocal: !mainComponent.key,
      parentComponentName: parentComponentName ? parentComponentName : null,
      mainComponentKey: mainComponent.key,
      mainComponentId: mainComponent.id,
      fileKey: figma.fileKey,
      icon: isIcon,
      size: isIcon ? width : `${width}x${height}`,
      isNested: isNested,
      
    };
  }

  return null;
}