// Show the UI
figma.showUI(__html__, { width: 600, height: 1000 });

// Add cache storage at the top level
const componentUpdateCache = new Map();
// Добавляем массив для хранения результатов проверок
let resultsList = [];

// Добавляем глобальную переменную для хранения данных о цветах
let lastColorsData = null;

/**
 * Получает уникальный ключ кэширования для компонента
 * Если компонент находится в наборе компонентов (COMPONENT_SET),
 * использует комбинацию ключа родителя и имени компонента,
 * иначе использует собственный ключ компонента
 * @param {ComponentNode} component - Компонент для получения ключа
 * @returns {string} Уникальный ключ для кэширования
 */
function getComponentCacheKey(component) {
  try {
    // Проверяем наличие компонента
    if (!component) {
      console.error('getComponentCacheKey: компонент не определен');
      return 'undefined_component';
    }

    // Проверяем наличие ключа компонента
    if (!component.key) {
      console.error('getComponentCacheKey: у компонента отсутствует ключ');
      return `no_key_${component.id || 'unknown'}`;
    }

    // Проверяем наличие родителя и его тип
    if (component.parent && component.parent.type === 'COMPONENT_SET' && component.parent.key) {
      return `${component.parent.key}_${component.name || 'unnamed'}`;
    }

    return component.key;
  } catch (error) {
    console.error('Ошибка в getComponentCacheKey:', error);
    return `error_${component.id || 'unknown'}`;
  }
}

/**
 * Проверяет, требует ли компонент обновления
 * Сравнивает текущий компонент с импортированной версией
 * Использует кэширование для оптимизации повторных проверок
 * @param {ComponentNode} mainComponent - Компонент для проверки
 * @returns {Promise<{isOutdated: boolean, importedId: string|null}>}
 */
async function checkComponentUpdate(mainComponent) {
  // Проверяем входные данные
  if (!mainComponent) {
    console.error('checkComponentUpdate: получен пустой компонент');
    return {
      isOutdated: false,
      importedId: null,
      mainComponentId: null,
      importedMainComponentId: null
    };
  }

  try {
    const cacheKey = getComponentCacheKey(mainComponent);
    
    console.log('Проверка компонента:', {
      name: mainComponent.name,
      key: mainComponent.key,
      id: mainComponent.id,
      mainComponentId: mainComponent.id,
      parentType: mainComponent.parent ? mainComponent.parent.type : 'нет родителя'
    });

  let result = {
    isOutdated: false,
      importedId: null,
      version: null,
      description: null,
      mainComponentId: mainComponent.id,
      importedMainComponentId: null
    };

    // Проверяем наличие ключа у компонента
    if (!mainComponent.key) {
      console.log('У компонента отсутствует ключ:', mainComponent.name);
      componentUpdateCache.set(cacheKey, result);
      return result;
    }

    const isPartOfSet = mainComponent.parent && mainComponent.parent.type === 'COMPONENT_SET';
    let importedComponent = null;

    if (isPartOfSet && mainComponent.parent && mainComponent.parent.key) {
      try {
        console.log('Импортируем набор компонентов:', {
          parentKey: mainComponent.parent.key,
          componentName: mainComponent.name,
          mainComponentId: mainComponent.id
        });
        
        const importedSet = await figma.importComponentSetByKeyAsync(mainComponent.parent.key);
        
        
        
        
        
        if (importedSet) {
          console.log('Набор компонентов ', importedSet.name, "импортирован");
          let foundMatch = false; // Флаг для отслеживания совпадений
          importedComponent = importedSet.findChild(comp => {
            /*console.log('Сравниваем компонент:', {
              name: comp.name,
              targetName: mainComponent.name,
              type: comp.type,
              local_mainComponentId: mainComponent.id,
              imported_MainComponentId: comp.id,
              matches: comp.name === mainComponent.name && comp.type === 'COMPONENT'
            });*/
            if (comp.name === mainComponent.name && comp.type === 'COMPONENT') {
              foundMatch = true; // Устанавливаем флаг, если найдено совпадение
              return true;
            }
            return false;
          });

          //const descriptionData = getDescription(importedSet);
          
          result = {
            isOutdated: importedComponent ? importedComponent.id !== mainComponent.id : false,
            mainComponentId: mainComponent.id,
            libraryComponentId: importedComponent ? importedComponent.id : null,
            libraryComponentVersion: getDescription(importedSet).nodeVersion,
            description: getDescription(importedSet).description
          };
          
          
          if (!foundMatch) {
            // Если совпадений не найдено, устанавливаем isOutdated в true
            result.isOutdated = true;
            console.log('Совпадений по ID в наборе не найдено');
           }

           //console.log('Результат проверки компонента из набора — ', result);console.log('Результат проверки компонента из набора — ', result);

          console.log('Результат поиска в наборе:', foundMatch ? 'Компонент с таким ID в наборе не найден' : result);
        } else {
          console.log('Не удалось импортировать набор компонентов');
        }
      } catch (setError) {
        console.error('Ошибка при импорте набора компонентов:', setError);
      }
    } else {
      try {
        console.log('Импортируем отдельный компонент по ключу:', {
          key: mainComponent.key,
          mainComponentId: mainComponent.id
        });
        importedComponent = await figma.importComponentByKeyAsync(mainComponent.key);
        console.log('Результат импорта компонента:', importedComponent ? {
          success: true,
          importedMainComponentId: importedComponent.id,
          mainComponentId: mainComponent.id
        } : 'не удалось');
      } catch (componentError) {
        console.error('Ошибка при импорте компонента:', componentError);
      }
      
    result = {
      isOutdated: importedComponent ? importedComponent.id !== mainComponent.id : false,
        importedId: importedComponent ? importedComponent.id : null,
        version: importedComponent ? extractVersion(importedComponent.description) : null,
        mainComponentId: mainComponent.id,
        importedMainComponentId: importedComponent ? importedComponent.id : null,
        description: importedComponent ? getDescription(importedComponent).description : null
      };
    
    }
    

    // Сохраняем результат в кэш
    //componentUpdateCache.set(cacheKey, result);
    
    console.log('Результат проверки компонента:', {
      name: mainComponent.name,
      isOutdated: result.isOutdated,
      //cacheKey,
      libraryComponentId: result.libraryComponentId,
      libraryComponentVersion: result.libraryComponentVersion,
    });
    return result;

  } catch (error) {
    console.error('Ошибка при проверке компонента:', {
      componentName: mainComponent ? mainComponent.name : 'неизвестно',
      error: error.message,
      stack: error.stack
    });
    
    const safeResult = {
      isOutdated: false,
      importedId: null,
      libraryName: null,
      mainComponentId: mainComponent ? mainComponent.id : null,
      importedMainComponentId: null
    };
    
    try {
      const cacheKey = getComponentCacheKey(mainComponent);
      componentUpdateCache.set(cacheKey, safeResult);
    } catch (cacheError) {
      console.error('Не удалось сохранить результат в кэш:', cacheError);
    }

    return safeResult;
  }
}

/**
 * Получает полный путь к узлу через всех его родителей
 * Формирует строку из ID всех родительских узлов, разделенных запятыми
 * @param {SceneNode} node - Узел для получения пути
 * @returns {string} Строка пути, состоящая из ID узлов
 */
function getNodePath(node) {
  const path = [];
  let current = node;

  // Collect all IDs along the parent chain
  while (current && current.parent) {
    path.unshift(current.id);
    current = current.parent;
  }

  // Form the path string, adding the necessary separators
  return path.join(',');
}

/**
 * Извлекает версию из описания, если она соответствует паттерну
 * @param {string} description - Описание компонента
 * @returns {string|null} Версия или null, если паттерн не найден
 */
function extractVersion(description) {
  if (!description) return null;
  
  // Паттерн: "v" + пробел + три числа, разделенные точками
  const versionPattern = /^v\s+(\d+\.\d+\.\d+)/;
  const match = description.match(versionPattern);
  
  return match ? match[1] : null;
}

/**
 * Получает описание узла
 * Проверяет наличие описания в следующем порядке:
 * 1. У самого узла
 * 2. У главного компонента
 * 3. У родителя главного компонента
 * @param {SceneNode} node - Узел для получения описания
 * @returns {Object} Объект с описанием и версией
 */
function getDescription(node) {
  let description = node.description;
  let nodeVersion = null;

  if (!description && node.mainComponent) {
    description = node.mainComponent.description;
    if (!description && node.mainComponent.parent) {
      description = node.mainComponent.parent.description;
    }
  }

  if (description) {
    nodeVersion = extractVersion(description);
  }

  return {
    description: description || "",
    nodeVersion: nodeVersion
  };
}

/**
 * Проверяет, скрыт ли узел или любой из его родителей
 * Рекурсивно проверяет свойство visible для узла и всех его родителей
 * @param {SceneNode} node - Узел для проверки
 * @returns {boolean} true если узел или любой из родителей скрыт
 */
function isNodeOrParentHidden(node) {
  let currentNode = node;
  while (currentNode) {
    if (currentNode.visible === false) {
      return true; // Если текущий узел скрыт, возвращаем true
    }
    currentNode = currentNode.parent; // Переходим к родителю
  }
  return false; // Если ни один из узлов не скрыт, возвращаем false
}

/**
 * Проверяет, является ли узел вложенным в другой экземпляр
 * Рекурсивно проверяет родителей узла на тип INSTANCE
 * @param {SceneNode} node - Узел для проверки
 * @returns {boolean} true если узел вложен в другой экземпляр
 */
function isNestedInstance(node) {
  let parent = node.parent;
  while (parent) {
    if (parent.type === 'INSTANCE') {
      return true;
    }
    parent = parent.parent;
  }
  return false;
}

// Добавляем вспомогательную функцию для задержки
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Добавляем функцию для отправки прогресса
async function updateProgress(phase, processed, total, message) {
  figma.ui.postMessage({
    type: 'progress-update',
    phase,
    processed,
    total,
    message
  });
  // Небольшая задержка для обработки UI
}

/**
 * Основной обработчик сообщений от UI плагина
 * Обрабатывает следующие типы сообщений:
 * 
 * 1. 'list-instances':
 *    - Ищет все экземпляры компонентов в выбранном фрейме/секции
 *    - Собирает информацию о каждом экземпляре (имя, размеры, описание и т.д.)
 *    - Определяет, является ли компонент иконкой на основе размеров и имени
 *    - Отправляет собранные данные обратно в UI
 * 
 * 2. 'list-colors':
 *    - Анализирует все элементы в выбранном фрейме/секции на наличие цветов
 *    - Собирает информацию о заливках, обводках и связанных переменных
 *    - Проверяет API переменных Figma и логирует отладочную информацию
 *    - Отправляет собранные данные о цветах обратно в UI
 * 
 * 3. 'scroll-to-node':
 *    - Находит узел по переданному ID
 *    - Прокручивает и масштабирует вид к найденному узлу
 *    - Выделяет узел в интерфейсе Figma
 * 
 * 4. 'select-nodes':
 *    - Принимает массив ID узлов
 *    - Находит все указанные узлы
 *    - Выделяет группу узлов в интерфейсе Figma
 *    - Прокручивает вид к выделенным узлам
 * 
 * 5. 'check-all':
 *    - Последовательно вызывает проверку компонентов и цветов
 *    - Собирает и отправляет результаты проверки в UI
 * 
 * @param {Object} msg - Объект сообщения от UI
 * @param {string} msg.type - Тип сообщения ('list-instances', 'list-colors', 'scroll-to-node', 'select-nodes', 'check-all')
 * @param {string} [msg.nodeId] - ID узла для прокрутки (для 'scroll-to-node')
 * @param {string[]} [msg.nodeIds] - Массив ID узлов для выделения (для 'select-nodes')
 */
figma.ui.onmessage = async (msg) => {
  if (msg.type === 'check-all') {
    const selection = figma.currentPage.selection;

    if (!selection || selection.length === 0) {
      figma.ui.postMessage({ 
        type: 'error', 
        message: 'Выберите фрейм, компонент или инстанс!' 
      });
      return;
    }

    const container = selection[0];
    let componentsResult = {
      instances: [],
      counts: {
        components: 0,
        icons: 0
      }
    };
    let colorsResult = {
      instances: [],
      counts: {
        colors: 0
      }
    };

    try {
      let nodesToProcess = [];

      if (container.type === 'INSTANCE') {
        nodesToProcess = [container, ...container.findAll()];
      } else if (container.type === 'COMPONENT') {
        nodesToProcess = container.findAll();
      } else if (typeof container.findAll === 'function') {
        nodesToProcess = container.findAll();
      } else {
        figma.ui.postMessage({ 
          type: 'error', 
          message: 'Выбранный элемент не поддерживается. Пожалуйста, выберите фрейм, компонент или инстанс.' 
        });
        return;
      }
      
      await updateProgress('processing', 0, nodesToProcess.length, 'Обработка элементов');

      // Первый этап: основная проверка компонентов и цветов
      for (let i = 0; i < nodesToProcess.length; i++) {
        const node = nodesToProcess[i];
        
        if (hasFillOrStroke(node)) {
          const colorData = await processNodeColors(node);
          
          if (colorData) {
            colorsResult.instances.push(colorData);
            colorsResult.counts.colors++;
          }
        }

        if (node.type === 'INSTANCE' && node.mainComponent) {
          const instanceData = await processNodeComponent(node);
          if (instanceData) {
            componentsResult.instances.push(instanceData);
            if (instanceData.icon) {
              componentsResult.counts.icons++;
            } else {
              componentsResult.counts.components++;
            }
          }
        }

        if (i % 10 === 0 || i === nodesToProcess.length - 1) {
          await updateProgress('processing', i + 1, nodesToProcess.length, 'Обработка элементов');
        }
      }

      // Сортируем результаты
      componentsResult.instances.sort((a, b) => a.name.localeCompare(b.name));
      
      // Сохраняем результаты в общий массив
      resultsList = componentsResult.instances.map(instance => {
        return Object.assign({}, instance, {
          updateStatus: null // Будет заполнено позже при проверке обновлений
        });
      });

      // Сохраняем данные о цветах
      lastColorsData = colorsResult;

      console.error('Цвет:', colorsResult);
      
      // Отправляем первичные результаты в UI
      figma.ui.postMessage({
        type: 'all-results',
        components: componentsResult,
        colors: colorsResult
      });
      await delay(1000);
      // Второй этап: асинхронная проверка обновлений
      await checkComponentUpdates(componentsResult);
      
    } catch (error) {
      console.error('Ошибка при проверке:', error);
      figma.notify(`Ошибка при проверке: ${error.message}`);
      figma.ui.postMessage({ type: 'error', message: `Ошибка при проверке: ${error.message}` });
      return;
    }
  } 
  // Обработка запроса на получение списка экземпляров компонентов
  
  // Обработка запроса на получение списка цветов
  else if (msg.type === 'list-colors') {
    // console.log("\n\n========= НАЧАЛО ОБРАБОТКИ СООБЩЕНИЯ list-colors =========");
    // console.log("Время начала:", new Date().toISOString());
    
    // Тестирование API переменных Figma
    // Проверяем доступность и работоспособность API
    // console.log("ТЕСТ: Проверяем API переменных Figma");
    // console.log("Доступные методы figma.variables:", Object.keys(figma.variables));
    
    try {
      // Получаем и проверяем локальные переменные
      // console.log("ТЕСТ: Получаем все локальные переменные");
      const localVars = await figma.variables.getLocalVariablesAsync();
      // console.log(`ТЕСТ: Получено ${localVars.length} локальных переменных`);
      
      // Тестируем работу с первой найденной переменной
      if (localVars.length > 0) {
        // console.log("ТЕСТ: Первая локальная переменная:", {
        //   id: localVars[0].id,
        //   name: localVars[0].name,
        //   key: localVars[0].key
        // });
        
        // console.log(`ТЕСТ: Пробуем получить переменную по ID: ${localVars[0].id}`);
        const testVar = await figma.variables.getVariableByIdAsync(localVars[0].id);
        // console.log("ТЕСТ: Результат вызова getVariableByIdAsync:", testVar ? {
        //   id: testVar.id,
        //   name: testVar.name,
        //   key: testVar.key
        // } : "не найдена");
      }
    } catch (testError) {
      // console.error("ТЕСТ: Ошибка при тестировании API переменных:", testError);
    }
    
    // Проверяем наличие выбранных элементов
    const selection = figma.currentPage.selection;

    if (!selection || selection.length === 0) {
      // console.log("Ошибка: Нет выбранных элементов");
      figma.ui.postMessage({ type: 'error', message: 'Выберите фрейм или секцию!' });
      return;
    }

    // Собираем информацию о цветах
    try {
      // console.log('Начинаем сбор информации о цветах...');
    const container = selection[0];
      // console.log(`Выбран контейнер: ${container.name}, type: ${container.type}, id: ${container.id}`);
      
      // Вызываем функцию сбора цветов и обрабатываем результаты
      // console.log('Вызываем функцию collectColors');
      const colorData = await collectColors(container);
      // console.log(`Собрано ${colorData.length} элементов с цветами`);
      
      // Отправляем результаты в UI
      if (colorData.length === 0) {
        // console.log("Ошибка: Цвета не найдены");
        figma.ui.postMessage({ type: 'error', message: 'Цвета не найдены!' });
      } else {
        // Логируем примеры собранных данных для отладки
        // console.log('Пример собранных данных (первые 3 элемента):', 
        //   colorData.slice(0, 3).map(item => ({
        //     name: item.name,
        //     fill: item.fill,
        //     fill_variable_name: item.fill_variable_name,
        //     stroke: item.stroke,
        //     stroke_variable_name: item.stroke_variable_name
        //   }))
        // );
        
        // Отправляем данные в UI
        // console.log('Отправляем данные в UI');
        figma.ui.postMessage({ 
          type: 'success', 
          instances: colorData,
          counts: {
            components: 0,
            icons: 0,
            colors: colorData.length
          }
        });
      }
    } catch (error) {
      // console.error('Ошибка при сборе цветов:', error);
      figma.notify(`Ошибка при сборе цветов: ${error.message}`);
      figma.ui.postMessage({ type: 'error', message: `Ошибка при сборе цветов: ${error.message}` });
    }
    
    // console.log("Время окончания:", new Date().toISOString());
    // console.log("========= КОНЕЦ ОБРАБОТКИ СООБЩЕНИЯ list-colors =========\n\n");
  } 
  // Обработка запроса на прокрутку к определенному узлу
  else if (msg.type === 'scroll-to-node') {
    const nodeId = msg.nodeId;

    // Ищем узел по ID
    // console.log('Ищем узел с ID:', nodeId);
    const node = figma.getNodeById(nodeId);

    // Если узел найден, прокручиваем к нему и выделяем
    if (node) {
      // Прокручиваем и увеличиваем масштаб до выбранного узла
      figma.viewport.scrollAndZoomIntoView([node]);
      figma.currentPage.selection = [node]; // Выделяем узел
    } else {
      // console.error('Узел не найден:', nodeId);
      figma.notify('Не удалось найти узел с указанным ID.');
    }
  } 
  // Обработка запроса на выбор группы узлов
  else if (msg.type === 'select-nodes') {
    const nodeIds = msg.nodeIds;
    // console.log('Выбираем группу узлов:', nodeIds);
    
    // Проверяем корректность входных данных
    if (!nodeIds || nodeIds.length === 0) {
      figma.notify('Не указаны ID узлов для выбора');
      return;
    }
    
    // Находим все узлы по их ID и фильтруем несуществующие
    const nodes = nodeIds
      .map(id => figma.getNodeById(id))
      .filter(node => node !== null);
    
    // Проверяем, найдены ли узлы
    if (nodes.length === 0) {
      figma.notify('Не удалось найти ни один из указанных узлов');
      return;
    }
    
    // Выделяем найденные узлы и прокручиваем к ним
    figma.currentPage.selection = nodes;
    
    if (nodes.length > 0) {
      figma.viewport.scrollAndZoomIntoView(nodes);
      figma.notify(`Выбрано ${nodes.length} элементов`);
    }
  }
};

/**
 * Собирает информацию о цветах во всех узлах контейнера
 * Анализирует заливки и обводки, собирает информацию о:
 * - Цветах (hex)
 * - Переменных цвета
 * - Коллекциях цветов
 * - Родительских компонентах
 * @param {ContainerNode} container - Контейнер для анализа
 * @returns {Promise<Array>} Массив данных о цветах
 */
async function collectColors(container) {
  const colorData = [];
  const allNodes = container.findAll();
  
  console.log(`Начинаем анализ ${allNodes.length} узлов для поиска цветов`);
  
  // Проходим по всем узлам
    for (const node of allNodes) {
    // Проверяем наличие свойств fill и stroke
    if (hasFillOrStroke(node)) {
      console.log(`Найден узел с цветом: ${node.name}, type: ${node.type}`);
      
      const nodeData = {
        name: node.name,
        nodeId: node.id,
        key: node.key,
        modifiedName: node.name,
        color: true,
        description: getDescription(node),
        hidden: isNodeOrParentHidden(node)
      };
      
      // Находим родителя с типом INSTANCE, если он есть
      let parentComponentName = null;
      let parentNode = node.parent;

      while (parentNode && !parentComponentName) {
        if (parentNode.type === 'INSTANCE' && parentNode.mainComponent) {
          parentComponentName = parentNode.mainComponent.name;
          if (parentNode.mainComponent.parent && parentNode.mainComponent.parent.type === 'COMPONENT_SET') {
            parentComponentName = parentNode.mainComponent.parent.name;
          }
          break;
        }
        parentNode = parentNode.parent;
      }

      if (parentComponentName) {
        nodeData.parentComponentName = parentComponentName;
      }
      
      // Обрабатываем заливку
      if (node.fills && node.fills.length > 0) {
        for (const fill of node.fills) {
          if (fill.type === 'SOLID' && fill.visible !== false) {
            if (fill.color && fill.color.r !== figma.mixed && fill.color.g !== figma.mixed && fill.color.b !== figma.mixed) {
              nodeData.fill = rgbToHex(fill.color.r, fill.color.g, fill.color.b);
              console.log(`Заливка: ${nodeData.fill}`);
            } else {
              nodeData.fill = '#MIXED';
            }
            break;
          }
        }
      }
      
      // Обрабатываем обводку
      if (node.strokes && node.strokes.length > 0) {
        for (const stroke of node.strokes) {
          if (stroke.type === 'SOLID' && stroke.visible !== false) {
            if (stroke.color && stroke.color.r !== figma.mixed && stroke.color.g !== figma.mixed && stroke.color.b !== figma.mixed) {
              nodeData.stroke = rgbToHex(stroke.color.r, stroke.color.g, stroke.color.b);
              console.log(`Обводка: ${nodeData.stroke}`);
            } else {
              nodeData.stroke = '#MIXED';
            }
            break;
          }
        }
      }

      // Проверяем условие: игнорируем элементы с цветом #000000 и родителем "source"
      const hasBlackColor = (nodeData.fill === '#000000' || nodeData.stroke === '#000000');
      let hasSourceParent = false;
      
      let parent = node.parent;
      while (parent) {
        if (parent.name && parent.name.toLowerCase().includes('source')) {
          hasSourceParent = true;
          break;
        }
        parent = parent.parent;
      }
      
      // Добавляем узел в набор данных, только если он не соответствует критериям фильтрации
      if (!(hasBlackColor && hasSourceParent)) {
        colorData.push(nodeData);
        console.log(`Добавлен узел: ${nodeData.name} с цветами fill: ${nodeData.fill}, stroke: ${nodeData.stroke}`);
      }
    }
  }
  
  console.log(`Всего найдено ${colorData.length} элементов с цветами`);
  
  // Отправляем результаты в UI
  figma.ui.postMessage({ 
    type: 'success', 
    instances: colorData,
    counts: {
      components: 0,
      icons: 0,
      colors: colorData.length
    }
  });
  
  return colorData;
}

/**
 * Проверяет наличие заливки или обводки у узла
 * Анализирует свойства fills и strokes на наличие видимых
 * сплошных цветов (SOLID)
 * @param {SceneNode} node - Узел для проверки
 * @returns {boolean} true если узел имеет заливку или обводку
 */
function hasFillOrStroke(node) {
  try {
    // Проверяем fills
    if (node.fills && node.fills.length > 0) {
      const hasValidFill = node.fills.some(fill => {
        return fill.type === 'SOLID' && 
               fill.visible !== false && 
               fill.color && 
               fill.color.r !== figma.mixed && 
               fill.color.g !== figma.mixed && 
               fill.color.b !== figma.mixed;
      });
      if (hasValidFill) return true;
    }
    
    // Проверяем strokes
    if (node.strokes && node.strokes.length > 0) {
      const hasValidStroke = node.strokes.some(stroke => {
        return stroke.type === 'SOLID' && 
               stroke.visible !== false && 
               stroke.color && 
               stroke.color.r !== figma.mixed && 
               stroke.color.g !== figma.mixed && 
               stroke.color.b !== figma.mixed;
      });
      if (hasValidStroke) return true;
    }
    
    return false;
  } catch (error) {
    console.error('Ошибка при проверке заливки/обводки:', error);
    return false;
  }
}

/**
 * Преобразует RGB цвет в HEX формат
 * Обрабатывает особые случаи:
 * - figma.mixed значения
 * - Некорректные значения
 * - Масштабирование из диапазона 0-1 в 0-255
 * @param {number} r - Красный компонент (0-1)
 * @param {number} g - Зеленый компонент (0-1)
 * @param {number} b - Синий компонент (0-1)
 * @returns {string} Цвет в формате HEX (#RRGGBB)
 */
function rgbToHex(r, g, b) {
  // Проверка на Symbol (figma.mixed)
  if (r === figma.mixed || g === figma.mixed || b === figma.mixed) {
    // console.log('Обнаружено figma.mixed в цветовых компонентах');
    return '#MIXED';
  }
  
  // Убедимся, что значения определены и являются числами
  if (typeof r !== 'number' || typeof g !== 'number' || typeof b !== 'number') {
    // console.error(`Некорректные значения для RGB: r=${r}, g=${g}, b=${b}`);
    return '#ERROR';
  }
  
  // Масштабируем значения от 0-1 до 0-255
  r = Math.round(r * 255);
  g = Math.round(g * 255);
  b = Math.round(b * 255);
  
  // Проверяем границы значений
  r = Math.max(0, Math.min(255, r));
  g = Math.max(0, Math.min(255, g));
  b = Math.max(0, Math.min(255, b));
  
  // Преобразуем в шестнадцатеричный формат
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
}

/**
 * Безопасно сериализует объект в JSON строку
 * Обрабатывает специальные случаи:
 * - Symbol значения
 * - Циклические ссылки
 * - Несериализуемые объекты
 * @param {Object} obj - Объект для сериализации
 * @returns {string} JSON строка или сообщение об ошибке
 */
function safeStringify(obj) {
  try {
    return JSON.stringify(obj, (key, value) => {
      // Заменяем Symbol на строковое представление
      if (typeof value === 'symbol') {
        return 'Symbol(' + value.description + ')';
      }
      return value;
    });
  } catch (error) {
    // console.error('Ошибка при сериализации объекта:', error.message);
    return '"[Объект не может быть сериализован]"';
  }
}

/**
 * Обрабатывает цвета для отдельного узла
 * @param {SceneNode} node - Узел для обработки
 * @returns {Promise<Object|null>} Данные о цветах узла или null
 */
async function processNodeColors(node) {
  console.log(`\n=== Начало обработки цветов для узла "${node.name}" (ID: ${node.id}) ===`);
  
  const nodeData = {
    name: node.name,
    nodeId: node.id,
    key: node.key,
    modifiedName: node.name,
    color: true,
    hidden: isNodeOrParentHidden(node),
    type: node.type
  };
  
  console.log('Базовые данные узла:', {
    name: nodeData.name,
    id: nodeData.nodeId,
    type: nodeData.type,
    hidden: nodeData.hidden
  });

  // Находим родительский компонент
  console.log('Поиск родительского компонента...');
  let parentComponentName = null;
  let parentNode = node.parent;
  
  while (parentNode && !parentComponentName) {
    console.log(`Проверка родителя: ${parentNode.type} (${parentNode.name})`);
    if (parentNode.type === 'INSTANCE' && parentNode.mainComponent) {
      parentComponentName = parentNode.mainComponent.name;
      if (parentNode.mainComponent.parent && parentNode.mainComponent.parent.type === 'COMPONENT_SET') {
        parentComponentName = parentNode.mainComponent.parent.name;
        console.log(`Найден родительский компонент в наборе: ${parentComponentName}`);
      } else {
        console.log(`Найден родительский компонент: ${parentComponentName}`);
      }
    }
    parentNode = parentNode.parent;
  }

  if (parentComponentName) {
    nodeData.parentComponentName = parentComponentName;
    console.log(`Установлено имя родительского компонента: ${parentComponentName}`);
  } else {
    console.log('Родительский компонент не найден');
  }

  // Обрабатываем заливку
  console.log('\nОбработка заливки...');
  if (node.fills && node.fills.length > 0) {
    console.log(`Найдено ${node.fills.length} заливок`);
    for (const fill of node.fills) {
      if (fill.type === 'SOLID' && fill.visible !== false) {
        console.log('Найдена видимая сплошная заливка');
        if (fill.color && fill.color.r !== figma.mixed && fill.color.g !== figma.mixed && fill.color.b !== figma.mixed) {
          nodeData.fill = rgbToHex(fill.color.r, fill.color.g, fill.color.b);
          console.log(`Цвет заливки преобразован в HEX: ${nodeData.fill}`);
        } else {
          nodeData.fill = '#MIXED';
          console.log('Обнаружен смешанный цвет заливки');
        }
        break;
      }
    }
  } else {
    console.log('Заливки не найдены');
  }

  // Обрабатываем обводку
  console.log('\nОбработка обводки...');
  if (node.strokes && node.strokes.length > 0) {
    console.log(`Найдено ${node.strokes.length} обводок`);
    for (const stroke of node.strokes) {
      if (stroke.type === 'SOLID' && stroke.visible !== false) {
        console.log('Найдена видимая сплошная обводка');
        if (stroke.color && stroke.color.r !== figma.mixed && stroke.color.g !== figma.mixed && stroke.color.b !== figma.mixed) {
          nodeData.stroke = rgbToHex(stroke.color.r, stroke.color.g, stroke.color.b);
          console.log(`Цвет обводки преобразован в HEX: ${nodeData.stroke}`);
        } else {
          nodeData.stroke = '#MIXED';
          console.log('Обнаружен смешанный цвет обводки');
        }
        break;
      }
    }
  } else {
    console.log('Обводки не найдены');
  }

  // Обрабатываем переменные
  console.log('\nОбработка привязок переменных...');
  if (node.boundVariables) {
    console.log('Найдены привязки переменных');
    await processVariableBindings(node, nodeData, 'fills', 'fill');
    await processVariableBindings(node, nodeData, 'strokes', 'stroke');
  } else {
    console.log('Привязки переменных не найдены');
  }

  // Проверяем условия фильтрации
  console.log('\nПроверка условий фильтрации...');
  const hasBlackColor = (nodeData.fill === '#000000' || nodeData.stroke === '#000000');
  console.log(`Имеет черный цвет: ${hasBlackColor}`);
  
  let hasSourceParent = false;
  let parent = node.parent;
  while (parent) {
    if (parent.name && parent.name.toLowerCase().includes('source')) {
      hasSourceParent = true;
      console.log(`Найден родитель "source": ${parent.name}`);
      break;
    }
    parent = parent.parent;
  }
  console.log(`Имеет родителя "source": ${hasSourceParent}`);

  // Возвращаем null если элемент нужно отфильтровать
  if (hasBlackColor && hasSourceParent) {
    console.log('Элемент отфильтрован: черный цвет и родитель "source"');
    return null;
  }

  console.log('\nИтоговые данные узла:', nodeData);
  console.log(`=== Завершена обработка узла "${node.name}" ===\n`);
  return nodeData;
}

/**
 * Обрабатывает компонент для отдельного узла
 * @param {InstanceNode} node - Узел компонента для обработки
 * @returns {Promise<Object|null>} Данные о компоненте или null
 */
async function processNodeComponent(node) {
  const mainComponent = node.mainComponent;
  let name = mainComponent.name;
  let parentComponentName = null;
  let parentNode = node.parent;

  // Проверяем, находится ли инстанс внутри другого инстанса
  let isNested = false;
  let parent = node.parent;
  while (parent) {
    if (parent.type === 'INSTANCE') {
      isNested = true;
      break;
    }
    parent = parent.parent;
  }

  const descriptionData = getDescription(node);

  while (parentNode && !parentComponentName) {
    if (parentNode.type === 'INSTANCE' && parentNode.mainComponent) {
      parentComponentName = parentNode.mainComponent.name;
      if (parentNode.mainComponent.parent && parentNode.mainComponent.parent.type === 'COMPONENT_SET') {
        parentComponentName = parentNode.mainComponent.parent.name;
      }
    }
    parentNode = parentNode.parent;
  }

      if (mainComponent.parent && mainComponent.parent.type === 'COMPONENT_SET') {
        name = mainComponent.parent.name;
      }

      if (typeof name === 'string' && name.trim() !== "") {
        const width = Math.round(node.width);
        const height = Math.round(node.height);

        const dimensionsMatch = width === height;
        const nameStartsWithNumber = /^\d+/.test(name);
        const hasSlashAfterNumber = /^\d+\s\//.test(name);
    const hasNumberTextSlashPattern = /^\d+\s.+\s\/\s/.test(name);
    
    const isIcon = dimensionsMatch && 
                    (nameStartsWithNumber && hasSlashAfterNumber || hasNumberTextSlashPattern);

    return {
      type: node.type,
          name: name.trim(),
      modifiedName: name.trim().replace(' (new)', ''),
      description: descriptionData.description,
      nodeVersion: descriptionData.nodeVersion,
      hidden: isNodeOrParentHidden(node),
      nodeId: node.id,
          isLocal: !mainComponent.key,
      parentComponentName: parentComponentName ? parentComponentName : null,
      mainComponentKey: mainComponent.key,
      mainComponentId: mainComponent.id,
          fileKey: figma.fileKey,
          icon: isIcon,
          size: isIcon ? width : `${width}x${height}`,
          isNested: isNested,
      skipUpdate: isNested // Добавляем флаг для пропуска проверки обновлений
    };
  }

  return null;
}

async function checkComponentUpdates(componentsResult) {
  console.log('\n=== Начинаем проверку обновлений компонентов ===');
  
  // Используем сохраненные данные о цветах из глобальной переменной
  const colorsData = lastColorsData || { instances: [], counts: { colors: 0 } };
  
  for (let i = 0; i < componentsResult.instances.length; i++) {
    const instance = componentsResult.instances[i];
    
    try {
      if (!instance.mainComponentId) {
        console.log(`\nПропускаем компонент "${instance.name}" - отсутствует mainComponentId`);
        continue;
      }

      // Пропускаем вложенные компоненты
      if (instance.skipUpdate) {
        console.log(`\nПропускаем вложенный компонент "${instance.name}"`);
        continue;
      }

      console.log(`\nПроверяем компонент: "${instance.name}" (mainComponentId: ${instance.mainComponentId})`);
      const mainComponent = figma.getNodeById(instance.mainComponentId);
      
      if (!mainComponent) {
        console.log(`Не удалось найти компонент по ID: ${instance.mainComponentId}`);
        continue;
      }

      const updateInfo = await checkComponentUpdate(mainComponent);

      console.log('ПРОВЕРКА:',updateInfo);
      
      // Обновляем информацию в массиве результатов
      componentsResult.instances[i] = Object.assign({}, instance, {
        isOutdated: updateInfo.isOutdated,
        libraryComponentId: updateInfo.libraryComponentId,
        libraryComponentVersion: updateInfo.libraryComponentVersion,
        mainComponentId: updateInfo.mainComponentId
      });

      // Отправляем обновление в UI с сохранением данных о цветах
      figma.ui.postMessage({ 
        type: 'all-results',
        components: {
          instances: componentsResult.instances,
          counts: componentsResult.counts
        },
        colors: colorsData // Используем сохраненные данные о цветах
      });

      console.log('Результат проверки:', {
        componentName: instance.name,
        isOutdated: updateInfo.isOutdated,
        importedId: updateInfo.importedId,
        mainComponentId: updateInfo.mainComponentId,
        importedMainComponentId: updateInfo.importedMainComponentId,
        version: updateInfo.version
      });
    } catch (componentError) {
      console.error(`Ошибка при проверке компонента "${instance.name}":`, componentError);
      continue;
    }
  }
  
  console.log('\n=== Проверка обновлений компонентов завершена ===');
}

/**
 * Обрабатывает привязки переменных для узла
 * @param {SceneNode} node - Узел для обработки
 * @param {Object} nodeData - Объект с данными узла
 * @param {string} propertyType - Тип свойства ('fills' или 'strokes')
 * @param {string} prefix - Префикс для имени свойства ('fill' или 'stroke')
 */
async function processVariableBindings(node, nodeData, propertyType, prefix) {
  console.log(`\n--- Обработка привязок для ${propertyType} (префикс: ${prefix}) ---`);
  
  if (node.boundVariables && node.boundVariables[propertyType]) {
    console.log(`Найдены привязки для ${propertyType}`);
    const binding = node.boundVariables[propertyType][0];
    
    if (binding) {
      console.log(`Обработка привязки: ${binding.id}`);
      try {
        const variable = await figma.variables.getVariableByIdAsync(binding.id);
        if (variable) {
          nodeData[`${prefix}_variable_name`] = variable.name;
          
          // Получаем коллекцию переменной
          try {
            const collection = await figma.variables.getVariableCollectionByIdAsync(variable.variableCollectionId);
            if (collection) {
              nodeData[`${prefix}_collection_name`] = collection.name;
              nodeData[`${prefix}_collection_id`] = collection.id;
              console.log('Успешно получены данные переменной:', {
                variableName: variable.name,
                collectionName: collection.name,
                collectionId: collection.id
              });
            } else {
              console.log('Коллекция не найдена');
              nodeData[`${prefix}_collection_name`] = 'Коллекция не найдена';
            }
          } catch (collectionError) {
            console.error(`Ошибка при получении коллекции: ${collectionError}`);
            nodeData[`${prefix}_collection_name`] = 'Ошибка получения коллекции';
          }
        } else {
          console.log('Переменная не найдена по ID');
        }
      } catch (error) {
        console.error(`Ошибка при обработке переменной для ${propertyType}:`, error);
        nodeData[`${prefix}_variable_name`] = false;
        console.log(`Установлено ${prefix}_variable_name = false из-за ошибки`);
      }
    } else {
      console.log('Привязка не содержит данных');
    }
  } else {
    console.log(`Привязки для ${propertyType} не найдены`);
  }
  
  console.log(`--- Завершена обработка привязок для ${propertyType} ---\n`);
}
